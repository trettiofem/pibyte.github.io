#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <sstream>

#include "bfour.h"

using namespace std;

typedef unsigned long nibble;

bFour::instruction bFour::newInstruction(nibble _opcode, nibble _arg1, nibble _arg2, nibble _arg3)
{
	instruction final;

	final.opcode = _opcode;
	final.arg1 = _arg1;
	final.arg2 = _arg2;
	final.arg3 = _arg3;

	return final;
}

void bFour::setup()
{
	/* Loading config file (config.txt) */
	string line;
	ifstream conf("config.txt");
	if (conf.is_open())
	{
		while (getline(conf, line))
		{
			if (line == "true")
				debugMode = true;
		}
		conf.close();
	}
	else
		cout << "Config file could not be found!\n" << endl;

	/* Loading ROM file! */

	string fle;
	cout << "Enter name of .beef file: ";
	cin >> fle;
	

	unsigned char x;
	stringstream stream;

	ifstream romfile;
	romfile.open(fle.c_str(), ios_base::binary);
	romfile >> noskipws;
	if (romfile.is_open())
	{
		while (romfile >> x)
		{
			stream << hex << setw(2) << setfill('0') << (int)x;
		}
	}
	else
		cout << "ROM file could not be found\n(Or beef found rather... hehe :))\n" << endl;

	string final;
	final = stream.str();


	int j = 0;

	for (int i = 0; i < final.length(); i += 4)
	{
		string one = final.substr(i, 4);

		rom[j] = newInstruction(strtoul(one.substr(0, 1).c_str(), 0, 16), strtoul(one.substr(1, 1).c_str(), 0, 16), strtoul(one.substr(2, 1).c_str(), 0, 16), strtoul(one.substr(3, 1).c_str(), 0, 16));

		j++;
	}

	if (debugMode)
	{
		for (int i = 0; i < 16; i++)
		{
			cout << hex << rom[i].opcode << rom[i].arg1 << rom[i].arg2 << rom[i].arg3 << endl;
		}
		cout << endl;
	}


}

void bFour::opcode()
{

	/* Run and execute each opcode */

	if (debugMode)
		cout << "Instruction at 0x" << hex << working << ": 0x" << hex << rom[working].opcode << endl;

	switch (rom[working].opcode)
	{
	case 0x0:
		/* There is nothing here, my good Sir! */
	break;
	case 0x1:
		reg[rom[working].arg1] = rom[working].arg2;
	break;
	case 0x2:
		ram[rom[working].arg2] = reg[rom[working].arg1];
	break;
	case 0x3:
		reg[rom[working].arg2] = ram[rom[working].arg1];
	break;
	case 0x4:
		working = rom[working].arg1 - 1;
	break;
	case 0x5:
		reg[rom[working].arg3] = reg[rom[working].arg1] + reg[rom[working].arg2];
	break;
	case 0x6:
		reg[rom[working].arg3] = reg[rom[working].arg1] - reg[rom[working].arg2];
	break;
	case 0x7:
		if (reg[rom[working].arg1] ^ reg[rom[working].arg2])
			working = rom[working].arg3 - 1;
	break;
	case 0x8:
		if (reg[rom[working].arg1] | reg[rom[working].arg2])
			working = rom[working].arg3 - 1;
	break;
	case 0x9:
		if (reg[rom[working].arg1] & reg[rom[working].arg2])
			working = rom[working].arg3 - 1;
	break;
	case 0xA:
		if (reg[rom[working].arg1] == reg[rom[working].arg2])
			working = rom[working].arg3 - 1;
	break;
	case 0xB:
		if (reg[rom[working].arg1] > reg[rom[working].arg2])
			working = rom[working].arg3 - 1;
	break;
	case 0xC:
		if (reg[rom[working].arg1] < reg[rom[working].arg2])
			working = rom[working].arg3 - 1;
	break;
	case 0xD:
		reg[rom[working].arg2] = reg[rom[working].arg1];
	break;
	case 0xE:
		cout << reg[rom[working].arg1] << endl;
	break;
	case 0xF:
		cout << "Program stopped at " << hex << "0x" << working << endl;
		stopped = true;
	break;
	default:
		cout << "Unknown opcode at position " << hex << "0x" << working << ": 0x" << rom[working].opcode << endl;
		stopped = true;
	break;

	}
	if (!stopped && debugMode)
	{
		cout << "Press ENTER to continue\n";
		cout << "Reg0: " << hex << reg[0] << endl;
		cout << "Reg1: " << hex << reg[1] << endl;
		cout << "Reg2: " << hex << reg[2] << endl;
		cout << "Reg3: " << hex << reg[3] << endl;
		cin.get();
	}

	working++;
}