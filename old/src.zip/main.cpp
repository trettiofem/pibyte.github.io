/* BEEFY COMPOOPER EMULATOR v. 0.00001 */
/* BCE */

/* COPYRIGHT ME 2016 */

#include <iostream> 

#include "bfour.h"

/* TODO: */
/* Load external ROM files */
/* Clean up code!!! */
/* Design a new computer+emulator (hopefully an 8-bit one) */

using namespace std;

int main()
{
	/* Setup emulator */
	cout << "4-bit bFour emulation\n" << endl;

	bFour BCE;

	BCE.setup();
	do
	{
		BCE.opcode();
	} while (!BCE.stopped);
	cout << "\nPress ENTER to close emulator";

	/* Cin.get(); is kind of shitty, this is the easiest way to get around a stupid bug */
	cin.get();
	cin.get();

	return 0;
}