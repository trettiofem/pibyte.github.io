#pragma once

#include <iostream>

#ifndef BFOUR_H
#define BFOUR_H
#endif

class bFour
{
public:
	bool stopped = false;

	bool debugMode = false;

	void setup();
	void opcode();


private:
	typedef unsigned short nibble;

	typedef struct
	{
		nibble opcode;
		nibble arg1;
		nibble arg2;
		nibble arg3;
	} instruction;

	nibble ram[16] = {}; //Ram (16*4 bits)
	nibble reg[16] = {}; //Registors

	instruction rom[16] = {}; //Program ROM

	nibble working = 0x0; //Current opcode

	instruction newInstruction(nibble _opcode, nibble _arg1, nibble _arg2, nibble _arg3);
};